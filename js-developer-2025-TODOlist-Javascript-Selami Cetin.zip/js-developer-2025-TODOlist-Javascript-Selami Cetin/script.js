document.addEventListener('DOMContentLoaded', function() {
    // DOM elementleri
    const taskForm = document.getElementById('task-form');
    const taskList = document.getElementById('task-list');
    const titleInput = document.getElementById('task-title');
    const descriptionInput = document.getElementById('task-description');
    const priorityInputs = document.querySelectorAll('input[name="priority"]');
    const titleError = document.getElementById('title-error');
    const priorityError = document.getElementById('priority-error');
    const showAllBtn = document.getElementById('show-all');
    const showPendingBtn = document.getElementById('show-pending');
    const showCompletedBtn = document.getElementById('show-completed');
    const sortPriorityBtn = document.getElementById('sort-priority');
    const totalTasksEl = document.getElementById('total-tasks');
    const completedTasksEl = document.getElementById('completed-tasks');
    const pendingTasksEl = document.getElementById('pending-tasks');
    
    // Görevler dizisi
    let tasks = [];
    let currentFilter = 'all';
    let sortByPriority = false;
    
    // Form gönderme işlemi
    taskForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        try {
            // Form doğrulama
            if (!validateForm()) {
                return;
            }
            
            // Görev objesi oluştur
            const task = {
                id: Date.now(),
                title: titleInput.value.trim(),
                description: descriptionInput.value.trim(),
                priority: getSelectedPriority(),
                completed: false,
                date: new Date().toLocaleString('tr-TR')
            };
            
            // Görevi listeye ekle
            tasks.push(task);
            
            // Görevi DOM'a ekle
            renderTasks();
            
            // Formu temizle
            taskForm.reset();
            
            // Hata mesajlarını gizle
            titleError.style.display = 'none';
            priorityError.style.display = 'none';
            
            // İstatistikleri güncelle
            updateStats();
            
        } catch (error) {
            console.error('Beklenmedik bir hata oluştu:', error);
            alert('Bir hata oluştu. Lütfen tekrar deneyin.');
        }
    });
    
    // Form doğrulama fonksiyonu
    function validateForm() {
        let isValid = true;
        
        // Başlık doğrulama
        if (titleInput.value.trim() === '') {
            titleError.style.display = 'block';
            isValid = false;
        } else {
            titleError.style.display = 'none';
        }
        
        // Öncelik doğrulama
        if (!getSelectedPriority()) {
            priorityError.style.display = 'block';
            isValid = false;
        } else {
            priorityError.style.display = 'none';
        }
        
        return isValid;
    }
    
    // Seçili önceliği alma
    function getSelectedPriority() {
        for (const input of priorityInputs) {
            if (input.checked) {
                return input.value;
            }
        }
        return null;
    }
    
    // Görevleri render etme
    function renderTasks() {
        // Filtreleme ve sıralama
        let filteredTasks = tasks;
        
        // Filtreleme
        if (currentFilter === 'pending') {
            filteredTasks = tasks.filter(task => !task.completed);
        } else if (currentFilter === 'completed') {
            filteredTasks = tasks.filter(task => task.completed);
        }
        
        // Sıralama (öncelik)
        if (sortByPriority) {
            const priorityOrder = { 'high': 1, 'medium': 2, 'low': 3 };
            filteredTasks.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
        }
        
        // Görev listesini oluştur
        if (filteredTasks.length === 0) {
            taskList.innerHTML = `
                <div class="empty-list-message">
                    <i class="fas fa-clipboard-list"></i>
                    <p>${currentFilter === 'completed' ? 'Tamamlanmış görev bulunmamaktadır' : 
                      currentFilter === 'pending' ? 'Bekleyen görev bulunmamaktadır' : 
                      'Görev listeniz boş. Hadi bir görev ekleyin!'}</p>
                </div>
            `;
        } else {
            taskList.innerHTML = '';
            filteredTasks.forEach(task => {
                const taskElement = createTaskElement(task);
                taskList.appendChild(taskElement);
            });
        }
    }
    
    // Görev elementini oluşturma
    function createTaskElement(task) {
        const taskElement = document.createElement('div');
        taskElement.className = `task-item ${task.completed ? 'completed' : ''}`;
        taskElement.dataset.id = task.id;
        
        // Öncelik etiketi
        let priorityLabel = '';
        switch (task.priority) {
            case 'low':
                priorityLabel = 'Düşük';
                break;
            case 'medium':
                priorityLabel = 'Orta';
                break;
            case 'high':
                priorityLabel = 'Yüksek';
                break;
        }
        
        taskElement.innerHTML = `
            <div class="task-header">
                <div class="task-title">${task.title}</div>
                <div class="task-priority priority-${task.priority}">${priorityLabel}</div>
            </div>
            ${task.description ? `<div class="task-description">${task.description}</div>` : ''}
            <div class="task-footer">
                <div class="task-date">${task.date}</div>
                <div class="task-actions">
                    <button class="task-btn complete-btn">
                        <i class="fas fa-${task.completed ? 'check-circle' : 'check'}"></i>
                        ${task.completed ? 'Tamamlandı' : 'Tamamla'}
                    </button>
                    <button class="task-btn delete-btn">
                        <i class="fas fa-trash"></i> Sil
                    </button>
                </div>
            </div>
        `;
        
        return taskElement;
    }
    
    // Event delegation ile görev işlemleri
    taskList.addEventListener('click', function(e) {
        const taskElement = e.target.closest('.task-item');
        if (!taskElement) return;
        
        const taskId = parseInt(taskElement.dataset.id);
        const task = tasks.find(t => t.id === taskId);
        
        if (!task) return;
        
        // Tamamlama butonu
        if (e.target.closest('.complete-btn')) {
            e.stopPropagation();
            task.completed = !task.completed;
            renderTasks();
            updateStats();
        }
        
        // Silme butonu
        if (e.target.closest('.delete-btn')) {
            e.stopPropagation();
            tasks = tasks.filter(t => t.id !== taskId);
            renderTasks();
            updateStats();
        }
    });
    
    // Filtreleme butonları
    showAllBtn.addEventListener('click', function() {
        setActiveButton(showAllBtn);
        currentFilter = 'all';
        renderTasks();
    });
    
    showPendingBtn.addEventListener('click', function() {
        setActiveButton(showPendingBtn);
        currentFilter = 'pending';
        renderTasks();
    });
    
    showCompletedBtn.addEventListener('click', function() {
        setActiveButton(showCompletedBtn);
        currentFilter = 'completed';
        renderTasks();
    });
    
    // Sıralama butonu
    sortPriorityBtn.addEventListener('click', function() {
        sortByPriority = !sortByPriority;
        sortPriorityBtn.classList.toggle('active', sortByPriority);
        renderTasks();
    });
    
    // Aktif butonu ayarlama
    function setActiveButton(activeButton) {
        [showAllBtn, showPendingBtn, showCompletedBtn].forEach(btn => {
            btn.classList.toggle('active', btn === activeButton);
        });
    }
    
    // İstatistikleri güncelleme
    function updateStats() {
        totalTasksEl.textContent = tasks.length;
        const completedCount = tasks.filter(task => task.completed).length;
        completedTasksEl.textContent = completedCount;
        pendingTasksEl.textContent = tasks.length - completedCount;
    }
    
    // Örnek görevler ekle (isteğe bağlı)
    function addSampleTasks() {
        tasks = [
            {
                id: 1,
                title: 'JavaScript Projesini Tamamla',
                description: 'Görev listesi uygulamasını tamamla ve test et',
                priority: 'high',
                completed: false,
                date: new Date().toLocaleString('tr-TR')
            },
            {
                id: 2,
                title: 'Alışveriş Listesi Hazırla',
                description: 'Haftalık alışveriş için ihtiyaç listesi oluştur',
                priority: 'medium',
                completed: true,
                date: new Date(Date.now() - 86400000).toLocaleString('tr-TR')
            },
            {
                id: 3,
                title: 'Kitap Oku',
                description: 'Her gün en az 30 sayfa kitap oku',
                priority: 'low',
                completed: false,
                date: new Date(Date.now() - 172800000).toLocaleString('tr-TR')
            }
        ];
        
        renderTasks();
        updateStats();
    }
    
    // Sayfa yüklendiğinde örnek görevleri ekle
    addSampleTasks();
});